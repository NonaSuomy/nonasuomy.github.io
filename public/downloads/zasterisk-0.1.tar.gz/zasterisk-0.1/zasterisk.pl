#!/usr/bin/perl

# Zasterisk 0.1, July, August 2005
#
# Written by Simon P. Ditner <simon@uc.org> as a platform to experiment with
# IVR, text-to-speech, and speech-to-text software
#
# Major components used:
# 	ZIO_Asterisk, a Games::Rezrov::ZIO compatible module, giving us access to a Z-Machine
# 	Asterisk::AGI, allows us to send commands to asterisk
# 	Net::Server, for FastAGI support
#
package Zasterisk;
@ISA = qw(Net::Server);

use lib qw(.);
use Asterisk::Games::Zork::StoryFile;		# Ever so slightly customized version of StoryFile, and ZInterpreter
use Asterisk::Games::Zork::ZInterpreter;  # to make them compatible with Asterisk
use Games::Rezrov::ZOptions;
use Games::Rezrov::ZConst;
use Net::Server;
use Asterisk::AGI;

use Asterisk::Games::Zork::ZIO_Asterisk; # This is where all the callback routines are defined for use by the ZInterpreter

# Start up a Net::Server object
Zasterisk->run(
	port=>4573,			# Default Asterisk FastAGI port
#	user=>'notroot',	# I don't recommend running anything as root, least of all this
#	group=>'other',
	background=>1,		# Detach from the console
);

#########

sub process_request {
  use vars qw(%input $AGI);
  STDIN->autoflush(1);
  $AGI = new Asterisk::AGI;
  $AGI->setcallback(\&mycallback);
  %input = $AGI->ReadParse();

  my $zio = new Asterisk::Games::Zork::ZIO_Asterisk( "columns" => 800, "rows" => 25, "AGI" => $AGI );
  my $story = new Games::Rezrov::StoryFile("ZORK1.DAT", $zio);
  Games::Rezrov::StoryFile::setup();
  my $zi = new Games::Rezrov::ZInterpreter($zio);

}

sub mycallback {
  my ($returncode) = @_;
  &log("CALLBACK");
  &cleanup;
  print STDERR "User Disconnected ($returncode)\n";
  exit($returncode);
}

sub log {
	print STDERR "LOG: User went away!\n";
}

sub cleanup {
	print STDERR "CLEANUP: Yep, all clean here.\n";
}
