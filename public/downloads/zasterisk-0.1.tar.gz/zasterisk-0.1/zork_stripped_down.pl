#!/usr/bin/perl -w

use strict;
use lib qw(.);

use Games::Rezrov::StoryFile;
use Games::Rezrov::ZOptions;
use Games::Rezrov::ZConst;

# This is where all the callback routines are defined for use by the ZInterpreter
use Asterisk::Games::Zork::ZIO_StrippedDown;

# Ever so slightly customized version of the ZInterpreter. Removed stray
# linefeeds, and unnecessary pauses for carriage returns.
use Asterisk::Games::Zork::ZInterpreter;	

my $zio = new Asterisk::Games::Zork::ZIO_StrippedDown( "columns" => 800, "rows" => 25 );

my $story = new Games::Rezrov::StoryFile("ZORK1.DAT", $zio);

Games::Rezrov::StoryFile::setup();

my $zi = new Games::Rezrov::ZInterpreter($zio);

